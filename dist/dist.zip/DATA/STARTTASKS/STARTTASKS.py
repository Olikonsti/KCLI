global taskimport; taskimport = ['RESTORE']
global tasklist; tasklist = []