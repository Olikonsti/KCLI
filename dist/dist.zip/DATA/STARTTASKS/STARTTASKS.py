global taskimport; taskimport = ['RESTORE', 'GUI']
global tasklist; tasklist = []