global taskimport; taskimport = []
global tasklist; tasklist = []