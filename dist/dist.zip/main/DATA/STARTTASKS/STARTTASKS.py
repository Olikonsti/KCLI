global taskimport; taskimport = ['RESTORE', 'POWDERGAME', 'GUI']
global tasklist; tasklist = []