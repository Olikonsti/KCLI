global taskimport; taskimport = ['PONG', 'GUI', 'ANGELSPIEL']
global tasklist; tasklist = ['GUI ']